import { combineReducers } from 'redux';
import selectedReducer from '../reducers/selectedReducer';

const globalReducer = combineReducers({
    selectedReducer: selectedReducer,
});

export default globalReducer;