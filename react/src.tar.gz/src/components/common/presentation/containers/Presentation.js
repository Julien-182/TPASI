import React, {Component} from 'react';
import './presentation.css';
import Slid from "../../slid/containers/Slid";

class Presentation extends Component {

    constructor(props) {
        super(props);
        this.getAllPres = this.getAllPres.bind(this);
    }

    getAllPres() {
        let display_result = this.props.slidArray.map(
            (slid) =>
                display_result = (
                    <Slid
                        id={slid.id}
                        title={slid.title}
                        content_id={slid.content_id}
                        txt={slid.txt}
                        content_list={this.props.content_list}
                        displayMode="SHORT"
                    ></Slid>
                )
        );

        return display_result;

    }

    render() {
        const display_list = this.getAllPres();
        return (
            <div>
                <label htmlFor="presTitle">
                    Title
                </label>
                <input
                    type="text" className="form-control"
                    id="presTitle"
                    onChange={this.props.handleChangeTitle}
                    value={this.props.title}/>
                <label htmlFor="prestText">
                    Description
                </label>
                <textarea
                    rows="5"
                    type="text"
                    className="form-control"
                    id="prestText"
                    onChange={this.props.handleChangeTxt}
                    value={this.props.description}>
                </textarea>
                {display_list}
            </div>
        )
    }

}

export default Presentation;