import React, {Component} from 'react';
import { connect } from 'react-redux';
import {setSelectedSlid} from "../../../../actions/index";
import OnlyContent from '../../content/components/OnlyContent';
import EditMetaSlid from '../../slid/components/EditMetaSlid'
import './slid.css';

class Slid extends Component {

    constructor(props) {
        super(props);
        this.updateSelectedSlid=this.updateSelectedSlid.bind(this);
    }

    updateSelectedSlid() {
        const tmpSlid = {
            id:this.props.id,
            title:this.props.title,
            txt:this.props.txt,
            content_id:this.props.content_id,
        };
        this.props.dispatch(setSelectedSlid(tmpSlid));
    }

    render() {
        let display_visual;
        let content = this.props.content_list[this.props.content_id];
        if (content === undefined) {
            content = this.props.content_list["1"];
        }
        if (this.props.displayMode == "SHORT") {
            display_visual = (
                <div  onClick={()=>{this.updateSelectedSlid()}}>
                    <h4>{this.props.title}</h4>
                    <p>{this.props.txt}</p>
                    <OnlyContent src={content.src}
                             title={content.title}
                             id={content.id}
                             type={content.type}
                    ></OnlyContent>
                </div>
            )
        }
        else if (this.props.displayMode == "FULL_MNG") {
            display_visual = (
                <div>
                    <EditMetaSlid
                        title={this.props.title}
                        txt={this.props.txt}>
                    </EditMetaSlid>
                    <OnlyContent src={content.src}
                                 title={content.title}
                                 id={content.id}
                                 type={content.type}
                    ></OnlyContent>
                </div>
            )
        }
        return display_visual;
    }

}

export default connect()(Slid);